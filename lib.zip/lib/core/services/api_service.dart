import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  ApiService._();
  static final ApiService instance = ApiService._();

  static const _base = 'https://api.vigiroutes.com/api';
  late final Dio _dio;
  VoidCallback? onUnauthorized;

  void init() {
    _dio = Dio(BaseOptions(
      baseUrl:        _base,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 60),
      headers: {'Accept': 'application/json', 'Content-Type': 'application/json'},
    ));

    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final prefs = await SharedPreferences.getInstance();
        final path  = options.path;

        // Routes /auth/* → aucun token nécessaire
        if (!path.startsWith('/auth/')) {
          final token = prefs.getString('sanctum_token');
          if (token != null) {
            options.headers['Authorization'] = 'Bearer $token';
          }
        }

        if (kDebugMode) debugPrint('[API] ${options.method} ${options.path}');
        handler.next(options);
      },
      onError: (err, handler) {
        if (err.response?.statusCode == 401 &&
            !err.requestOptions.path.contains('/auth/')) {
          onUnauthorized?.call();
        }
        handler.next(err);
      },
    ));
  }

  // ── Token ─────────────────────────────────────────────────────────────
  Future<void> saveToken(String token) async =>
      (await SharedPreferences.getInstance()).setString('sanctum_token', token);

  Future<void> clearToken() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('sanctum_token');
  }

  Future<bool> get hasToken async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey('sanctum_token');
  }

  // ── HTTP ──────────────────────────────────────────────────────────────
  Future<Response> get(String path, {Map<String, dynamic>? params}) =>
      _dio.get(path, queryParameters: params);
  Future<Response> post(String path, {dynamic data}) => _dio.post(path, data: data);
  Future<Response> patch(String path, {dynamic data}) => _dio.patch(path, data: data);
  Future<Response> delete(String path) => _dio.delete(path);

  // ══════════════════════════════════════════════════════════════════════
  //  Auth — Termii OTP (nouveau flux)
  // ══════════════════════════════════════════════════════════════════════

  /// Demande l'envoi d'un OTP au numéro donné.
  Future<void> sendOtp(String phone) async {
    await post('/auth/otp/send', data: {'phone': phone});
  }

  /// Vérifie l'OTP et connecte/crée un CLIENT.
  Future<Map<String, dynamic>> verifyOtpUser({
    required String phone,
    required String otp,
    String? fcmToken,
    String? name,
  }) async {
    final res = await post('/auth/otp/verify/user', data: {
      'phone': phone,
      'otp':   otp,
      if (fcmToken != null) 'fcm_token': fcmToken,
      if (name     != null) 'name':      name,
    });
    final data = res.data as Map<String, dynamic>;
    final token = data['token'] as String?;
    if (token != null) await saveToken(token);
    return data;
  }

  Future<void> logout() async {
    try { await post('/auth/logout'); } catch (_) {}
    await clearToken();
  }

  // ── Providers ─────────────────────────────────────────────────────────
  Future<List<dynamic>> getNearbyProviders({
    required double latitude, required double longitude,
    double radiusKm = 10, String? serviceTypeId,
  }) async {
    final res = await get('/user/providers/nearby', params: {
      'latitude': latitude, 'longitude': longitude, 'radius_km': radiusKm,
      if (serviceTypeId != null) 'service_type': serviceTypeId,
    });
    final d = res.data;
    if (d is Map && d['providers'] is List) return d['providers'] as List;
    return (d as List?) ?? [];
  }

  // ── Interventions ─────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getEstimate({
    required String serviceTypeId, required String providerId,
    required double userLat, required double userLng,
  }) async {
    final res = await post('/user/interventions/estimate', data: {
      'service_type_id': serviceTypeId, 'provider_id': providerId,
      'user_latitude': userLat, 'user_longitude': userLng,
    });
    return res.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> createIntervention(Map<String, dynamic> data) async {
    final res = await post('/user/interventions', data: data);
    return res.data as Map<String, dynamic>;
  }

  Future<List<dynamic>> getInterventions({int page = 1}) async {
    try {
      final res = await get('/user/interventions', params: {'page': page});
      return (res.data['data'] as List?) ?? [];
    } catch (_) { return []; }
  }

  Future<List<dynamic>> getUserInterventions({int page = 1}) =>
      getInterventions(page: page);

  Future<Map<String, dynamic>> getIntervention(String id) async {
    final res = await get('/user/interventions/$id');
    return res.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> submitReview({
    required String interventionId,
    required int    rating,
    String?         comment,
  }) async {
    final res = await post('/user/interventions/$interventionId/review', data: {
      'rating':  rating,
      if (comment != null && comment.isNotEmpty) 'comment': comment,
    });
    return res.data as Map<String, dynamic>;
  }

  Future<List<dynamic>> getNotifications({int page = 1}) async {
    try {
      final res = await get('/user/notifications', params: {'page': page});
      return (res.data['data'] as List?) ?? [];
    } catch (_) {
      return [];
    }
  }

  Future<void> markNotificationsRead() async {
    try {
      await post('/user/notifications/read-all');
    } catch (_) {}
  }

  Future<int> getUnreadNotificationsCount() async {
    try {
      final res = await get('/user/notifications/unread-count');
      return (res.data['count'] as num?)?.toInt() ?? 0;
    } catch (_) {
      return 0;
    }
  }

  Future<void> cancelIntervention(String id, {String? reason}) async {
    try { await post('/user/interventions/$id/cancel', data: {'reason': reason}); }
    catch (_) {}
  }

  Future<bool> updateInterventionStatus(String id, String status) async {
    try {
      await post('/user/interventions/$id/cancel', data: {'reason': status});
      return true;
    } catch (_) {
      return false;
    }
  }

  // ── Emergency ─────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> createEmergencyAlert({
    required String type, required double latitude, required double longitude,
    String? address, String? description,
  }) async {
    final res = await post('/user/emergency', data: {
      'type': type, 'latitude': latitude, 'longitude': longitude,
      if (address     != null) 'address':     address,
      if (description != null) 'description': description,
    });
    return res.data as Map<String, dynamic>;
  }

  // ── User ──────────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> getMe() async {
    final res = await get('/user/me');
    final d = res.data;
    if (d is Map && d['user'] is Map) {
      return Map<String, dynamic>.from(d['user'] as Map);
    }
    return Map<String, dynamic>.from(d as Map);
  }

  Future<Map<String, dynamic>> updateUser(Map<String, dynamic> data) async {
    final res = await patch('/user/me', data: data);
    final d = res.data;
    if (d is Map && d['user'] is Map) {
      return Map<String, dynamic>.from(d['user'] as Map);
    }
    return d is Map ? Map<String, dynamic>.from(d) : <String, dynamic>{};
  }

  Future<Map<String, dynamic>> uploadUserPhoto(String filePath) async {
    final form = FormData.fromMap({
      'photo': await MultipartFile.fromFile(filePath, filename: 'profile.jpg'),
    });
    final res = await _dio.post('/user/photo', data: form);
    final d = res.data;
    if (d is Map && d['user'] is Map) {
      return Map<String, dynamic>.from(d['user'] as Map);
    }
    return d is Map ? Map<String, dynamic>.from(d) : <String, dynamic>{};
  }

  Future<List<dynamic>> getUserReviews() async {
    try {
      final res = await get('/user/reviews');
      final d = res.data;
      if (d is Map && d['data'] is List) return d['data'] as List;
      return (d as List?) ?? [];
    } catch (_) { return []; }
  }

  Future<List<dynamic>> getReviewsGiven() async {
    try {
      final res = await get('/user/reviews/given');
      final d = res.data;
      if (d is Map && d['data'] is List) return d['data'] as List;
      return (d as List?) ?? [];
    } catch (_) { return []; }
  }

  // ── Vehicles ──────────────────────────────────────────────────────────
  Future<List<dynamic>> getVehicles() async {
    final res = await get('/user/vehicles');
    final d = res.data;
    if (d is Map && d['data'] is List) return d['data'] as List;
    if (d is Map && d['vehicles'] is List) return d['vehicles'] as List;
    return (d as List?) ?? [];
  }

  Future<Map<String, dynamic>> addVehicle(Map<String, dynamic> data) async {
    final res = await post('/user/vehicles', data: data);
    final d = res.data;
    if (d is Map && d['vehicle'] is Map) {
      return Map<String, dynamic>.from(d['vehicle'] as Map);
    }
    return d is Map ? Map<String, dynamic>.from(d) : <String, dynamic>{};
  }

  Future<void> deleteVehicle(String id) async {
    await delete('/user/vehicles/$id');
  }

  // ── Parts ─────────────────────────────────────────────────────────────

  /// Retourne les magasins les plus proches sans critère de pièce.
  /// Utilisé pour pré-remplir l'écran de recherche avant toute saisie.
  Future<List<dynamic>> getNearbyStores({
    required double latitude,
    required double longitude,
    double radiusKm = 5,
  }) async {
    final res = await get('/user/parts/stores/nearby', params: {
      'latitude':  latitude,
      'longitude': longitude,
      'radius_km': radiusKm,
    });
    return res.data as List<dynamic>;
  }

  Future<List<dynamic>> searchParts({
    required String query,
    required double latitude,
    required double longitude,
    double radiusKm = 3,
  }) async {
    final res = await get('/user/parts/search', params: {
      'q': query,
      'latitude': latitude,
      'longitude': longitude,
      'radius_km': radiusKm,
    });
    return res.data as List<dynamic>;
  }

  Future<Map<String, dynamic>> getStoreDetail(String storeId) async {
    final res = await get('/user/parts/stores/$storeId');
    return res.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> createPartOrder({
    required String storeId,
    required List<Map<String, dynamic>> items,
    String? note,
    double? deliveryLatitude,
    double? deliveryLongitude,
    String? deliveryAddress,
  }) async {
    final res = await post('/user/parts/orders', data: {
      'store_id': storeId,
      'items': items,
      if (note != null && note.isNotEmpty) 'note': note,
      if (deliveryLatitude != null) 'delivery_latitude': deliveryLatitude,
      if (deliveryLongitude != null) 'delivery_longitude': deliveryLongitude,
      if (deliveryAddress != null && deliveryAddress.isNotEmpty)
        'delivery_address': deliveryAddress,
    });
    return res.data as Map<String, dynamic>;
  }

  Future<List<dynamic>> getMyPartOrders({int page = 1}) async {
    try {
      final res = await get('/user/parts/orders', params: {'page': page});
      return (res.data['data'] as List?) ?? [];
    } catch (_) {
      return [];
    }
  }
}
